#version 330

// vanilla+ (B8, pack 0.4.3): vanilla rendertype_text of 1.21.9-1.21.10 + full-screen heat haze
// (see rendertype_text.vsh). The haze is a round vignette shaped like the screen: clear centre, a warm
// amber-to-red tint fading in smoothly towards the edges (smoothstep: no steps, no rings), strongest in
// the corners. The same formula lives in tools/haze.py (previews + fallback PNGs) - change both together.
// ASCII only in this file (some GL drivers reject other bytes).

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 vpScreen;
flat in vec4 vpHaze;

out vec4 fragColor;

const vec3 VP_HAZE_INNER = vec3(1.000, 0.690, 0.251);   // #FFB040 amber (where the haze is faint)
const vec3 VP_HAZE_OUTER = vec3(0.886, 0.227, 0.094);   // #E23A18 red-orange (towards the edges)

// +-0.5/255 dither noise: hides 8-bit banding of the smooth gradient (invisible by itself)
float vp_noise(vec2 p) {
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

// p: screen point in NDC (-1..1), k: strength 0..1, aspect: screen width / height
vec4 vp_heat_haze(vec2 p, float k, float aspect) {
    float sx = aspect / clamp(aspect, 1.0, 1.7778);       // wider than 16:9: keep the 16:9 ellipse
    float d = length(vec2(p.x * sx, p.y * 0.92));         // 0 centre, 1 middle of side edges, ~1.36 corners
    float r0 = mix(0.62, 0.28, k);                        // where the haze begins
    float t = clamp((d - r0) / (1.45 - r0), 0.0, 1.0);
    float s = t * t * (3.0 - 2.0 * t);                    // smooth start and end: no visible border
    return vec4(mix(VP_HAZE_INNER, VP_HAZE_OUTER, s), s * (0.06 + 0.62 * k));
}

void main() {
    if (vpHaze.x > 0.5) {
        vec4 h = vp_heat_haze(vpScreen, clamp(vpHaze.y, 0.0, 1.0), vpHaze.z);
        float a = (h.a + (vp_noise(gl_FragCoord.xy) - 0.5) / 255.0) * vpHaze.w * ColorModulator.a;
        if (a <= 0.0) {
            discard;
        }
        fragColor = vec4(h.rgb, a);
        return;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
