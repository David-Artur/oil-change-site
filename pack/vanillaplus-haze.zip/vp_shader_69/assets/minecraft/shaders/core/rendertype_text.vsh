#version 330

// vanilla+ (B8, pack 0.4.3): vanilla rendertype_text of 1.21.9-1.21.10 + full-screen heat haze.
// Marker: text colour RGB = (254, 253, B) drawn in the GUI (orthographic projection) - the heat haze
// glyph E072..E077 that the Leveling plugin puts into the actionbar. Its 4 vertices are pushed to the
// screen corners (by which side of the screen centre they are on); the fragment shader then draws the
// vignette procedurally (the glyph texture is not used). B = haze strength 1..255.
// Everything else is exactly vanilla. ASCII only in this file (some GL drivers reject other bytes).

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 vpScreen;        // haze: screen position in NDC (-1..1); 0 for normal text
flat out vec4 vpHaze;     // x: is haze (1/0), y: strength 0..1, z: screen aspect w/h, w: text alpha

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    vpScreen = vec2(0.0);
    vpHaze = vec4(0.0);
    ivec3 rgb = ivec3(round(Color.rgb * 255.0));
    if (rgb.r == 254 && rgb.g == 253 && rgb.b > 0 && ProjMat[2][3] == 0.0) {
        // glyph is 1280x720 GUI px: left vertices are left of the screen centre, right ones to the right;
        // bottom vertices sit on the bottom screen edge (NDC y = -1), top ones far above it
        vec2 ndc = gl_Position.xy / gl_Position.w;
        vec2 corner = vec2(ndc.x < 0.0 ? -1.0 : 1.0, ndc.y < -0.5 ? -1.0 : 1.0);
        gl_Position = vec4(corner * gl_Position.w, gl_Position.z, gl_Position.w);
        vpScreen = corner;
        vpHaze = vec4(1.0, float(rgb.b) / 255.0, abs(ProjMat[1][1] / ProjMat[0][0]), Color.a);
    }
}
